// Tokyo Tourism Guide JavaScript

// Data from the provided JSON
const touristSpots = [
  {
    "id": "sensoji",
    "name": "浅草寺",
    "category": "寺院・神社",
    "description": "東京最古の寺院で、伝統的な日本文化を体感できる人気スポット",
    "image": "https://pplx-res.cloudinary.com/image/upload/v1748590363/gpt4o_images/wokizvwtti9ono3uexw2.png",
    "details": {
      "address": "東京都台東区浅草2-3-1",
      "hours": "24時間開放（本堂は6:00〜17:00）",
      "admission": "無料",
      "access": "東京メトロ銀座線・都営浅草線・東武スカイツリーライン「浅草駅」から徒歩1分",
      "highlights": ["雷門と巨大な提灯", "仲見世通りでのお買い物", "五重塔", "おみくじ体験"],
      "best_season": "春（桜の季節）と秋（紅葉）",
      "nearby_food": ["仲見世通りの人形焼き", "天ぷら", "雷おこし", "抹茶スイーツ"]
    }
  },
  {
    "id": "meiji_jingu",
    "name": "明治神宮",
    "category": "寺院・神社",
    "description": "都心にある森に囲まれた神聖な神社",
    "image": "https://pplx-res.cloudinary.com/image/upload/v1748590673/gpt4o_images/bxgbvipmrnfiwkqmlebe.png",
    "details": {
      "address": "東京都渋谷区代々木神園町1-1",
      "hours": "5:00〜18:00（季節により変動）",
      "admission": "無料",
      "access": "JR山手線「原宿駅」から徒歩3分、JR山手線「代々木駅」から徒歩5分",
      "highlights": ["大鳥居", "森林浴", "季節の花菖蒲園", "御朱印", "結婚式見学"],
      "best_season": "春（桜・花菖蒲）と秋（紅葉）",
      "nearby_food": ["原宿のクレープ", "表参道のカフェ", "代々木のレストラン"]
    }
  },
  {
    "id": "imperial_palace",
    "name": "皇居",
    "category": "歴史・文化",
    "description": "天皇陛下のお住まいで、美しい庭園と江戸城跡を見学できる",
    "image": "https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=400&h=300&fit=crop",
    "details": {
      "address": "東京都千代田区千代田1-1",
      "hours": "東御苑：9:00〜16:00〜18:00（季節により変動）",
      "admission": "東御苑は無料、一般参観は要予約",
      "access": "JR「東京駅」から徒歩10分、東京メトロ「大手町駅」から徒歩5分",
      "highlights": ["江戸城跡", "二の丸庭園", "天守台", "無料ガイドツアー（水・土曜日）"],
      "best_season": "春（桜）と秋（紅葉）",
      "nearby_food": ["丸の内のレストラン街", "東京駅のグルメ", "大手町のカフェ"]
    }
  },
  {
    "id": "shibuya_crossing",
    "name": "渋谷スクランブル交差点",
    "category": "観光・街並み",
    "description": "世界で最も有名な交差点の一つで、東京の象徴的な風景",
    "image": "https://pplx-res.cloudinary.com/image/upload/v1748590451/gpt4o_images/acyrwz0dzzsmpwqwb2l2.png",
    "details": {
      "address": "東京都渋谷区道玄坂2丁目",
      "hours": "24時間",
      "admission": "無料",
      "access": "JR山手線「渋谷駅」ハチ公口から徒歩1分",
      "highlights": ["世界最大級のスクランブル交差点", "ハチ公像", "渋谷スクランブルスクエア展望台", "夜景"],
      "best_season": "一年中楽しめる（夜の照明は特に美しい）",
      "nearby_food": ["渋谷のレストラン街", "渋谷ヒカリエ", "渋谷フードショー", "センター街グルメ"]
    }
  },
  {
    "id": "tsukiji",
    "name": "築地場外市場",
    "category": "グルメ・市場",
    "description": "新鮮な海鮮とグルメが楽しめる食の宝庫",
    "image": "https://pplx-res.cloudinary.com/image/upload/v1748590508/gpt4o_images/z9eaogy5mh0csjtq8ymk.png",
    "details": {
      "address": "東京都中央区築地4丁目",
      "hours": "9:00〜14:00（多くの店舗）",
      "admission": "無料",
      "access": "都営大江戸線「築地市場駅」A1出口から徒歩1分、東京メトロ日比谷線「築地駅」から徒歩1分",
      "highlights": ["新鮮な海鮮丼", "まぐろの刺身", "玉子焼き", "寿司", "食べ歩き"],
      "best_season": "一年中（平日の朝がおすすめ）",
      "nearby_food": ["海鮮丼", "寿司", "まぐロール", "築地の玉子焼き", "新鮮な魚介類"]
    }
  },
  {
    "id": "odaiba",
    "name": "お台場",
    "category": "エンターテイメント",
    "description": "東京湾の人工島で、ショッピングとエンターテイメントの宝庫",
    "image": "https://images.unsplash.com/photo-1542640244-7e672d6cef4e?w=400&h=300&fit=crop",
    "details": {
      "address": "東京都港区台場",
      "hours": "施設により異なる",
      "admission": "公園エリアは無料、施設により有料",
      "access": "ゆりかもめ「台場駅」または「お台場海浜公園駅」、りんかい線「東京テレポート駅」",
      "highlights": ["実物大ガンダム立像", "レインボーブリッジの景色", "アクアシティお台場", "ダイバーシティ東京", "お台場海浜公園"],
      "best_season": "一年中楽しめる（夏は海辺、冬はイルミネーション）",
      "nearby_food": ["アクアシティのレストラン", "ダイバーシティのフードコート", "海鮮レストラン"]
    }
  },
  {
    "id": "ueno_park",
    "name": "上野公園",
    "category": "公園・動物園",
    "description": "パンダで有名な上野動物園がある文化的な公園",
    "image": "https://images.unsplash.com/photo-1580537659466-0a9bfa916a54?w=400&h=300&fit=crop",
    "details": {
      "address": "東京都台東区上野公園9-83",
      "hours": "動物園：9:30〜17:00、公園：24時間開放",
      "admission": "公園は無料、動物園：一般600円、65歳以上300円、中学生200円",
      "access": "JR「上野駅」公園口から徒歩5分",
      "highlights": ["ジャイアントパンダ", "約300種の動物", "桜の名所", "国立科学博物館", "東京国立博物館"],
      "best_season": "春（桜の季節）と秋（紅葉）",
      "nearby_food": ["上野アメ横グルメ", "動物園内レストラン", "老舗の和食店"]
    }
  },
  {
    "id": "shinjuku_gyoen",
    "name": "新宿御苑",
    "category": "公園・庭園",
    "description": "都心のオアシスで、四季折々の美しい景色が楽しめる国立庭園",
    "image": "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=400&h=300&fit=crop",
    "details": {
      "address": "東京都新宿区内藤町11",
      "hours": "9:00〜16:00（季節により変動）",
      "admission": "一般500円、65歳以上250円、学生250円、中学生以下無料",
      "access": "JR「新宿駅」南口から徒歩10分、東京メトロ丸ノ内線「新宿御苑前駅」から徒歩5分",
      "highlights": ["144エーカーの広大な庭園", "温室", "桜の名所", "紅葉", "ピクニック"],
      "best_season": "春（桜）と秋（紅葉）",
      "nearby_food": ["新宿のレストラン街", "御苑前のカフェ", "新宿サザンテラス"]
    }
  },
  {
    "id": "harajuku_takeshita",
    "name": "原宿・竹下通り",
    "category": "ショッピング・文化",
    "description": "日本のKawaii文化の発信地で、若者ファッションとグルメの聖地",
    "image": "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=400&h=300&fit=crop",
    "details": {
      "address": "東京都渋谷区神宮前1丁目",
      "hours": "店舗により異なる（多くは10:00〜20:00）",
      "admission": "無料",
      "access": "JR山手線「原宿駅」竹下口から徒歩0分",
      "highlights": ["約350mの商店街", "原宿系ファッション", "クレープ", "プリクラ", "インスタ映えスポット"],
      "best_season": "一年中楽しめる",
      "nearby_food": ["竹下通りのクレープ", "原宿のカラフルスイーツ", "ポップコーン", "可愛いカフェ"]
    }
  }
];

const seasonalData = {
  "spring": {
    "title": "春（3月〜5月）",
    "description": "桜の季節で東京が最も美しい時期",
    "highlights": ["桜の名所巡り", "花見", "温暖な気候"],
    "recommended_spots": ["浅草寺", "明治神宮", "皇居", "上野公園", "新宿御苑"]
  },
  "summer": {
    "title": "夏（6月〜8月）",
    "description": "お祭りとイベントが盛りだくさんの活気ある季節",
    "highlights": ["夏祭り", "花火大会", "お台場の海辺"],
    "recommended_spots": ["お台場", "上野公園", "築地場外市場"]
  },
  "autumn": {
    "title": "秋（9月〜11月）",
    "description": "美しい紅葉と過ごしやすい気候の観光ベストシーズン",
    "highlights": ["紅葉狩り", "快適な気候", "食べ物がおいしい季節"],
    "recommended_spots": ["明治神宮", "皇居", "新宿御苑", "上野公園"]
  },
  "winter": {
    "title": "冬（12月〜2月）",
    "description": "イルミネーションと澄んだ空気で特別な体験ができる季節",
    "highlights": ["イルミネーション", "初詣", "温かい料理"],
    "recommended_spots": ["明治神宮", "浅草寺", "渋谷スクランブル交差点", "原宿・竹下通り"]
  }
};

// DOM Elements
const spotsGrid = document.getElementById('spotsGrid');
const seasonContent = document.getElementById('seasonContent');
const seasonTabs = document.querySelectorAll('.season-tab');
const modal = document.getElementById('spotModal');
const modalBody = document.getElementById('modalBody');
const modalClose = document.getElementById('modalClose');
const modalBackdrop = document.getElementById('modalBackdrop');
const hamburger = document.getElementById('hamburger');
const navMenu = document.querySelector('.nav-menu');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
  renderTouristSpots();
  renderSeasonContent('spring');
  setupEventListeners();
  setupSmoothScrolling();
  addLoadingAnimations();
});

// Render tourist spots
function renderTouristSpots() {
  spotsGrid.innerHTML = '';
  
  touristSpots.forEach(spot => {
    const spotCard = document.createElement('div');
    spotCard.className = 'spot-card loading';
    spotCard.dataset.spotId = spot.id;
    spotCard.innerHTML = `
      <img src="${spot.image}" alt="${spot.name}" class="spot-card__image" onerror="this.src='https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&h=300&fit=crop'">
      <div class="spot-card__content">
        <span class="spot-card__category">${spot.category}</span>
        <h3 class="spot-card__name">${spot.name}</h3>
        <p class="spot-card__description">${spot.description}</p>
        <button class="spot-card__btn" data-spot-id="${spot.id}">詳細を見る</button>
      </div>
    `;
    spotsGrid.appendChild(spotCard);
    
    // Add click event listener directly to the card and button
    spotCard.addEventListener('click', function(e) {
      if (e.target.classList.contains('spot-card__btn') || !e.target.closest('.spot-card__btn')) {
        openSpotModal(spot.id);
      }
    });
  });
}

// Open spot modal
function openSpotModal(spotId) {
  const spot = touristSpots.find(s => s.id === spotId);
  if (!spot) return;

  const mapQuery = encodeURIComponent(spot.details.address);
  const mapUrl = `https://www.google.com/maps/search/?api=1&query=${mapQuery}`;
  
  modalBody.innerHTML = `
    <img src="${spot.image}" alt="${spot.name}" class="modal-spot__image" onerror="this.src='https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&h=300&fit=crop'">
    <h2 class="modal-spot__title">${spot.name}</h2>
    <div class="modal-spot__info">
      <div class="modal-info__item">
        <h4>基本情報</h4>
        <p><strong>住所:</strong> ${spot.details.address}</p>
        <p><strong>営業時間:</strong> ${spot.details.hours}</p>
        <p><strong>入場料:</strong> ${spot.details.admission}</p>
        <a href="${mapUrl}" target="_blank" rel="noopener noreferrer" class="modal-map-link">Google Mapsで見る</a>
      </div>
      <div class="modal-info__item">
        <h4>アクセス</h4>
        <p>${spot.details.access}</p>
      </div>
      <div class="modal-info__item">
        <h4>見どころ</h4>
        <ul>
          ${spot.details.highlights.map(highlight => `<li>${highlight}</li>`).join('')}
        </ul>
      </div>
      <div class="modal-info__item">
        <h4>おすすめの季節</h4>
        <p>${spot.details.best_season}</p>
      </div>
      <div class="modal-info__item">
        <h4>周辺グルメ</h4>
        <ul>
          ${spot.details.nearby_food.map(food => `<li>${food}</li>`).join('')}
        </ul>
      </div>
    </div>
  `;
  
  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

// Close spot modal
function closeSpotModal() {
  modal.classList.remove('active');
  document.body.style.overflow = '';
}

// Render season content
function renderSeasonContent(season) {
  const seasonInfo = seasonalData[season];
  if (!seasonInfo) return;

  seasonContent.innerHTML = `
    <div class="season-info">
      <h3>${seasonInfo.title}</h3>
      <p>${seasonInfo.description}</p>
      <div class="season-highlights">
        ${seasonInfo.highlights.map(highlight => `<span class="season-highlight">${highlight}</span>`).join('')}
      </div>
      <div class="recommended-spots">
        <h4>おすすめスポット</h4>
        <p>${seasonInfo.recommended_spots.join('、')}</p>
      </div>
    </div>
  `;
}

// Setup event listeners
function setupEventListeners() {
  // Season tabs
  seasonTabs.forEach(tab => {
    tab.addEventListener('click', function() {
      const season = this.dataset.season;
      
      // Update active tab
      seasonTabs.forEach(t => t.classList.remove('active'));
      this.classList.add('active');
      
      // Render content
      renderSeasonContent(season);
    });
  });

  // Modal close events - Fix for modal closing
  if (modalClose) {
    modalClose.addEventListener('click', function() {
      closeSpotModal();
    });
  }
  
  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', function() {
      closeSpotModal();
    });
  }
  
  // Close modal on Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && modal.classList.contains('active')) {
      closeSpotModal();
    }
  });

  // Mobile navigation toggle
  if (hamburger) {
    hamburger.addEventListener('click', function() {
      this.classList.toggle('active');
      navMenu.classList.toggle('active');
    });
  }

  // Close mobile menu when clicking on links
  if (navMenu) {
    navMenu.addEventListener('click', function(e) {
      if (e.target.tagName === 'A') {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
      }
    });
  }

  // Window resize handler
  window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
      if (hamburger) hamburger.classList.remove('active');
      if (navMenu) navMenu.classList.remove('active');
    }
  });

  // Direct event listeners for spot detail buttons
  document.addEventListener('click', function(e) {
    if (e.target.classList.contains('spot-card__btn')) {
      const spotId = e.target.dataset.spotId;
      if (spotId) {
        openSpotModal(spotId);
      }
    }
  });
}

// Setup smooth scrolling for navigation links
function setupSmoothScrolling() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        const headerHeight = document.querySelector('.header').offsetHeight;
        const targetPosition = target.offsetTop - headerHeight - 20;
        
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });
}

// Add loading animations
function addLoadingAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('loaded');
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  // Observe all loading elements
  setTimeout(() => {
    document.querySelectorAll('.loading').forEach(el => {
      observer.observe(el);
    });
  }, 100);
}

// Make functions global for use in HTML
window.openSpotModal = openSpotModal;
window.closeSpotModal = closeSpotModal;